#include <iostream>

using namespace std;

int main() {
   bool isTrue = false;
   
   isTrue ? cout << "hello" : cout << "bye";
}
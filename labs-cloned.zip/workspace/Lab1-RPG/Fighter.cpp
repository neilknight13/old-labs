#include "Fighter.h"

using namespace std;

string Fighter::getName() const {
		return name;
}

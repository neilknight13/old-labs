#include <string>
#include <vector>
#include <iostream>

using namespace std;

int main() {
   double test = 15.0 / 20.0;
   cout << test << endl;
}
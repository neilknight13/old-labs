#include <iostream>
#include "Pathfinder.h"
using namesapce std;

int main() {
   Pathfinder* pathptr = NULL; // the pathfinder
   //test 2D array
   pathptr = new Pathfinder();
   pathptr->importMaze
}
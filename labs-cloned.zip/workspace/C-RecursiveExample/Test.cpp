#include <string>
#include <iostream>

using namespace std;

int main() {
   int x = 5;
   cout << x / 2;
   return 0;
}
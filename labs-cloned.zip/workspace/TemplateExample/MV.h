template <class T>
class MV {
    T element;
  public:
    void put(T arg) {element = arg;};
    T get () {return element;}
};
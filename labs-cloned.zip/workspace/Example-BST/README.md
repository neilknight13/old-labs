# bst
In this learning activity, we will be experimenting with Binary Search Trees.  Download the code and compile it.

Once it is compiled, you can run it.  The code will prompt you to enter a number.  It will then insert the number into the Binary Search Tree and print out the preorder traversal.

When you enter a 0, then the program will transition to deleting the numbers from the Binary Search Tree.  When you have finished, enter a 0 to leave the program.

From Koffman, Elliot B. (2011-12-01). Objects, Abstraction, Data Structures and Design: Using C++. Wiley Higher Ed. Kindle Edition.

#include "Panda.h"

int Panda::getSpeed() {
   return (mySpeed / 2);
}
#include "Rocket.h"

int Rocket::getSpeed() {
   return (mySpeed * 2);
}
#include "Race.h"


using namespace std;
bool Race::addCar(string info) {
}

bool Race::removeCar(string name) {
}

CarInterface* Race::getCar(string name) {
}

int Race::getSize() const {
}
#include "Car.h"
string Car::getName() const {
		cout << "In Car getName"<<endl;
		return name;
};

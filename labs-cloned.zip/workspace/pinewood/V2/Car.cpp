#include "Car.h"
string Car::getName() const {
		cout << "In Car getName "<<name<<endl;
		return name;
};
